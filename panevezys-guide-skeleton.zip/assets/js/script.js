// Basic JS placeholder
document.addEventListener("DOMContentLoaded", () => {
  console.log("Panevėžys Guide loaded");
});
